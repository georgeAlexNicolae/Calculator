#include "Thread.h"

int main()
{
	Thread t;

	while (1)
	{
		t.run();
	}
	return 0;
}